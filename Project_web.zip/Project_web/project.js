

document.getElementById("Happy").addEventListener("click",function(){
 window.location.href="happy.html";
});

document.getElementById("Sad").addEventListener("click",function(){
 window.location.href="Sad.html";
});

document.getElementById("Focus").addEventListener("click",function(){
 window.location.href="focused.html";
});




const toggleButton = document.getElementById("toggle-Button");
const circle = document.getElementById("circle");
const body = document.body;

// load saved state
let isOn = localStorage.getItem("toggleState") === "true";

// initial state
if (isOn) {
  circle.style.transform = "translateX(30px)";
  circle.style.backgroundColor = "rgba(164, 155, 142, 0.99)";
  body.style.backgroundColor = "rgba(58, 56, 51, 0.973)";
} else {
  circle.style.transform = "translateX(0)";
  circle.style.backgroundColor = "black";
  body.style.backgroundColor = "rgba(130, 116, 98, 0.989)";
}

// click toggle
toggleButton.addEventListener("click", () => {
  isOn = !isOn;

  if (isOn) {
    circle.style.transform = "translateX(30px)";
    circle.style.backgroundColor = "rgba(164, 155, 142, 0.99)";
    body.style.backgroundColor = "rgba(58, 56, 51, 0.973)";
  } else {
    circle.style.transform = "translateX(0)";
    circle.style.backgroundColor = "black";
    body.style.backgroundColor = "rgba(130, 116, 98, 0.989)";
  }

  localStorage.setItem("toggleState", isOn);
});

const signupButton=document.getElementById("NoAccount");
const signupForm=document.getElementById("SignupForm");
const loginForm=document.getElementById("loginform");
signupButton.addEventListener("click",function(){
  signupForm.style.visibility="visible";
  loginForm.style.display="none";
});

const loginButton=document.getElementById("Loginform");
const SignInButton=document.getElementById("signin");
SignInButton.addEventListener("click",function(){
  
  loginForm.style.display="none";
});

const createAccountButton=document.getElementById("CreateAccount");
createAccountButton.addEventListener("click",function(){
  
  signupForm.style.visibility="hidden";
});