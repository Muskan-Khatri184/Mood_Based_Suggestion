let tabs = document.querySelectorAll(".tab");

tabs.forEach(tab => {
  tab.addEventListener("click", () => {

   
    tabs.forEach(t => {
      t.style.borderBottom = "none";
    });

   
    tab.style.borderBottom = "2px solid white";

  });
});
const motivationalvideoTab = document.getElementById("motivational-video");
const QuoteTab = document.getElementById("Quote");

const motivationalvideoContent = document.getElementById("motivational-video-content");
const QuoteContent = document.getElementById("Quote-content");


motivationalvideoContent.style.display = "flex";
QuoteContent.style.display = "none";


motivationalvideoTab.onclick = function () {
  motivationalvideoContent.style.display = "flex";
  QuoteContent.style.display = "none";
};


QuoteTab.onclick = function () {
  QuoteContent.style.display = "flex";
  motivationalvideoContent.style.display = "none";
};

const items = document.querySelectorAll("#Quote-content img");

let activeItem = null;   // yaad rakhega konsa item big hai

items.forEach(item => {
  item.onclick = function () {

    // agar yehi item already active hai → reset
    if (activeItem === this) {
      this.style.position = "static";
      this.style.zIndex = "1";
      this.style.width = "23%";
      this.style.height = "200px";
      activeItem = null;
      return;
    }

    // baaki sab reset
    items.forEach(i => {
      i.style.position = "static";
      i.style.zIndex = "1";
      i.style.width = "23%";
      i.style.height = "200px";
    });

    // clicked item big
    this.style.position = "fixed";
    this.style.zIndex = "999";
    this.style.width = "100%";
    this.style.height = "540px";

    activeItem = this;
  };
});



document.getElementById("Home").addEventListener("click",function(){
 window.location.href="project.html";
});