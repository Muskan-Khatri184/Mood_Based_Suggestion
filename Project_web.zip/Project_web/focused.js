let tabs = document.querySelectorAll(".tab");

tabs.forEach(tab => {
  tab.addEventListener("click", () => {

   
    tabs.forEach(t => {
      t.style.borderBottom = "none";
    });

   
    tab.style.borderBottom = "2px solid white";

  });
});
const studyVideo = document.getElementById("study-video");
const worldKnowledge = document.getElementById("world-knowledge");

const studyVideoContent = document.getElementById("study-video-content");
const worldKnowledgeContent = document.getElementById("world-knowledge-content");


studyVideoContent.style.display = "flex";
worldKnowledgeContent.style.display = "none";


studyVideo.onclick = function () {
  studyVideoContent.style.display = "flex";
  worldKnowledgeContent.style.display = "none";
};


worldKnowledge.onclick = function () {
  worldKnowledgeContent.style.display = "flex";
  studyVideoContent.style.display = "none";
};

document.getElementById("Home").addEventListener("click",function(){
 window.location.href="project.html";
});