let tabs = document.querySelectorAll(".tab");

tabs.forEach(tab => {
  tab.addEventListener("click", () => {

   
    tabs.forEach(t => {
      t.style.borderBottom = "none";
    });

   
    tab.style.borderBottom = "2px solid white";

  });
});
const movieTab = document.getElementById("tab1");
const songTab = document.getElementById("tab2");

const movieContent = document.getElementById("movie-content");
const songContent = document.getElementById("Song-content");


movieContent.style.display = "flex";
songContent.style.display = "none";


movieTab.onclick = function () {
  movieContent.style.display = "flex";
  songContent.style.display = "none";
};


songTab.onclick = function () {
  songContent.style.display = "flex";
  movieContent.style.display = "none";
};

document.getElementById("Home").addEventListener("click",function(){
 window.location.href="project.html";
});